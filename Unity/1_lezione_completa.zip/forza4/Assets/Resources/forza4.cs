﻿using UnityEngine;
using System.Collections;

public class forza4 : MonoBehaviour {

	GameObject[] oggetto_click= new GameObject[10];
	GameObject[] struttura= new GameObject[10];

	GameObject[] dischetto= new GameObject[100];

	int[] dischetto_fermo= new int[100];
	int[] dischetto_tipo= new int[100];
	int[] dischetto_colonna= new int[100];
	int[] dischetto_cella= new int[100];

	float[] dischetto_x= new float[100];
	float[] dischetto_y= new float[100];

	int[] colonna= new int[100];

	int che_colonna;
	int vittoria=-1;
	int partenza_colore;
	int ok_controllo;
	


	void Start () {
	
		for (int n=0;n<=9;n++){
			oggetto_click[n]=Instantiate(Resources.Load("struttura_click2"))  as GameObject; 
			oggetto_click[n].transform.position=new Vector3(90-n*10,0,0);


			oggetto_click[n].renderer.enabled = false;
			oggetto_click[n].name="colonna"+n;

			struttura[n]=Instantiate(Resources.Load("struttura_utile"))  as GameObject; 
			struttura[n].transform.position= new Vector3(90-n*10,0,0);
		}

		che_colonna=-1;


		for (int n=0;n<=99;n++){
			dischetto_cella[n]=-1;
		}

	}
	
	// Update is called once per frame
	void Update () {
	
		System.Threading.Thread.Sleep(27);
		
		click_colonna();
		inserisci_oggetto();
		disegna_oggetto();
		
		verifica_controllo();

		for (int t=0;t<=1;t++){
			controllo_orizzontale(t);
			controllo_verticale(t);
			controllo_diagonale_dx(t);
			controllo_diagonale_sx(t);
		}


	}


	void OnGUI(){

		GUI.Label (new Rect(0,0,300,50),""+che_colonna);

		GUI.Label (new Rect(0,100,300,50),""+vittoria);

	}



void click_colonna(){
	
	if (Input.GetMouseButton(0)   ){
		
			//Ray ray = camera.ScreenPointToRay(new Vector3(200, 200, 0));

			Ray ray2 = Camera.main.ScreenPointToRay(Input.mousePosition);

			RaycastHit hit;
			if (Physics.Raycast(ray2, out hit, 1000)){


			
			for (int n=0;n<=9;n++){

				if (hit.collider.name=="colonna"+n){
					che_colonna=n;
					
				}
				
			}
		}
		
	} 

}

	void inserisci_oggetto(){
		
		
		if (Input.GetMouseButtonDown(0) && vittoria==-1  ){
			
			if (che_colonna>-1 && che_colonna<10){
				
				
				
				int che_oggetto=0;
				
				for (int n=0;n<=99;n++){
					if (dischetto_fermo[n]==0){
						che_oggetto=n;
						n=10000;
					}
				}
				
				int ok=10;
				for (int n=0;n<=99;n++){
					if (dischetto_fermo[n]>1){
						ok=0;
						n=10000;
					}
				}

				
				
				if (colonna[che_colonna]<8 && ok==10){
					
					partenza_colore=1-partenza_colore;
					dischetto_tipo[che_oggetto]=partenza_colore;
					
				dischetto_colonna[che_oggetto]=che_colonna;
				dischetto_fermo[che_oggetto]=2;
				dischetto_x[che_oggetto]=90-che_colonna*10;
				dischetto_y[che_oggetto]=110;
					
				dischetto[che_oggetto]=Instantiate(Resources.Load("oggetto"+partenza_colore)) as GameObject; 
					
					
				}
				
			}
		}
		
	}


	void disegna_oggetto(){
		
		for (int n=0;n<=99;n++){
			
			if (dischetto_fermo[n]==2){
				dischetto_y[n]=dischetto_y[n]-5;
				
				int col=dischetto_colonna[n];
				int limite= (int) ((colonna[ col] )*10+10*.5f) ;
				
				if (dischetto_y[n]<limite){
					dischetto_y[n]=limite;
					dischetto_fermo[n]=1;
					
					int pos=colonna[col]+col*8;
					dischetto_cella[ pos  ]=dischetto_tipo[n];
					colonna[col]=colonna[col]+1;
					
					
				}
				
				
				
			}
			
			if (dischetto_fermo[n]>0){
				
				dischetto[n].transform.position=new Vector3(dischetto_x[n],dischetto_y[n],0);
				
				
			}
			
			
		}
		
		
	} 


	void verifica_controllo(){
		
		ok_controllo=10;
		for (int n=0;n<=99;n++){
			if (dischetto_fermo[n]>1){
				ok_controllo=0;
				n=10000;
			}
		}
		
		
		
		
	}


	void controllo_orizzontale(int tipo){
		
		
		
		
		if (ok_controllo==10){
			
			for (int riga=0;riga<=7;riga++){
				
				for (int col=0;col<=6;col++){
					
					int num=col*8+riga;
					
					int punti=0;
					
					if (dischetto_cella[num]==tipo){
						
						for (var k=0;k<=2;k++){
							if (dischetto_cella[num+k*8+8]==tipo){
								punti=punti+1;
							}
						}
						
					}
					
					
					if (punti==3){vittoria=tipo;}
					
					
				}
			}
			
			
		}

	}

	void controllo_verticale(int tipo){
		
		if (ok_controllo==10){
			
			for (int col=0;col<6;col++){
				for (int riga=0;riga<=9;riga++){
					
					
					int num=riga+col*8;
					
					int punti=0;
					
					if (dischetto_cella[num]==tipo){
						
						for (int k=0;k<=2;k++){
							if (dischetto_cella[num+k+1]==tipo){
								punti=punti+1;
							}
						}
						
					}
					
					
					if (punti==3){vittoria=tipo;}
					
					
				}
			}

		}
	}
		
	void controllo_diagonale_dx(int tipo){
		
		
		if (ok_controllo==10){
			
			
			for (int riga=0;riga<=7;riga++){
				for (int col=0;col<=6;col++){
					
					int num=col*8+riga;
					
					int punti=0;
					
					if (dischetto_cella[num]==tipo){
						
						for (int k=0;k<=2;k++){
							if (dischetto_cella[num+k*9+9]==tipo){
								punti=punti+1;
							}
						}
						
					}
					
					
					if (punti==3){vittoria=tipo;}
					
					
				}
			}
			
			
		}
		
	}

	void controllo_diagonale_sx(int tipo){
		
		
		if (ok_controllo==10){
			
			for (int riga=0;riga<=7;riga++){
				for (int col=3;col<=9;col++){
					
					int num=col*8+riga;
					
					int punti=0;
					
					if (num>-1){
						
						
						if (dischetto_cella[num]==tipo){
							
							for (int k=0;k<=2;k++){
								if (dischetto_cella[num-k*7-7]==tipo){
									punti=punti+1;
								}
							}
							
						}
						
					}
					
					
					
					if (punti==3){vittoria=tipo;}
					
					
				}
			}
			
			
		}
		
	}

}

