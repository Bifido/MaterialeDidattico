#pragma strict


private var colonna:int[];
colonna= new int[20];

private var oggetto : GameObject[];
oggetto = new GameObject[200];

private var oggetto_x: float[];
oggetto_x= new float[200];

private var oggetto_y: float[];
oggetto_y= new float[200];

private var oggetto_fermo: float[];
oggetto_fermo= new float[200];

private var oggetto_colonna: float[];
oggetto_colonna= new float[200];

private var oggetto_tipo: float[];
oggetto_tipo= new float[200];

private var oggetto_cella: float[];
oggetto_cella= new float[200];

private var ok_controllo;

private var dimex: int;
dimex=10;

private var vittoria: int;
vittoria=-1;

private var struttura: GameObject[];
struttura=new GameObject[10];

private var struttura_click: GameObject[];
struttura_click=new GameObject[10];

private var che_colonna: int;
private var partenza_colore: int;

private var col: int;
private var limite: int;
private var n: int;

function Start () {

for ( var n=0;n<=9;n++){
struttura[n]=Instantiate(Resources.Load("struttura_utile", GameObject)); 
struttura[n].transform.position=Vector3(n*10,0,0);
struttura_click[n]=Instantiate(Resources.Load("struttura_click2", GameObject)); 
struttura_click[n].transform.position=Vector3(90-n*10,0,0);

struttura_click[n].renderer.enabled = false;
struttura_click[n].name="colonna"+n;
}



for ( n=0;n<=199;n++){
oggetto_cella[n]=-1;
}


partenza_colore=Random.Range(.0,1.99);


}

function Update () {

System.Threading.Thread.Sleep(27);

click_colonna();
inserisci_oggetto();
disegna_oggetto();

verifica_controllo();

for (var t=0;t<=1;t++){
controllo_orizzontale(t);
controllo_verticale(t);
controllo_diagonale_dx(t);
controllo_diagonale_sx(t);
}


}



function click_colonna(){

if (Input.GetMouseButton(0)   ){

var ray2 = camera.ScreenPointToRay (Input.mousePosition);
//Debug.DrawRay (ray2.origin, ray2.direction * 30, Color.yellow);

var hit : RaycastHit; 
    if (Physics.Raycast (ray2, hit, 1000)) {


for (n=0;n<=9;n++){
//Debug.Log(""+hit.collider.name);
if (hit.collider.name=="colonna"+n){
che_colonna=n;
}

}
}

   } 


}




function OnGUI () {
	

GUI.color= Color(1,0,0);


GUILayout.Label(" che_colonna   "+che_colonna+" vittoria "+vittoria);	



}




function inserisci_oggetto(){


if (Input.GetMouseButtonDown(0) && vittoria==-1  ){

if (che_colonna>-1 && che_colonna<10){



var che_oggetto=0;

for (n=0;n<=199;n++){
if (oggetto_fermo[n]==0){
che_oggetto=n;
n=10000;
}
}



var ok=10;
for (n=0;n<=199;n++){
if (oggetto_fermo[n]>1){
	ok=0;
	n=10000;
	}
}


	if (colonna[che_colonna]<8 && ok==10){

partenza_colore=1-partenza_colore;
oggetto_tipo[che_oggetto]=partenza_colore;
	
	oggetto_colonna[che_oggetto]=che_colonna;
	oggetto_fermo[che_oggetto]=2;
	oggetto_x[che_oggetto]=90-che_colonna*dimex;
	oggetto_y[che_oggetto]=110;
	
oggetto[che_oggetto]=Instantiate(Resources.Load("oggetto"+partenza_colore, GameObject)); 


	}

}
}

}



function disegna_oggetto(){

for (n=0;n<=199;n++){

if (oggetto_fermo[n]==2){
oggetto_y[n]=oggetto_y[n]-5;

col=oggetto_colonna[n];
limite=(colonna[ col] )*dimex+dimex*.5;

if (oggetto_y[n]<limite){
oggetto_y[n]=limite;
oggetto_fermo[n]=1;

var pos=colonna[col]+col*8;
oggetto_cella[ pos  ]=oggetto_tipo[n];
colonna[col]=colonna[col]+1;


}



}

if (oggetto_fermo[n]>0){

oggetto[n].transform.position=Vector3(oggetto_x[n],oggetto_y[n],0);


}


}


} 


function verifica_controllo(){

ok_controllo=10;
for (n=0;n<=199;n++){
if (oggetto_fermo[n]>1){
	ok_controllo=0;
	n=10000;
	}
}




}


function controllo_orizzontale(tipo: int){




	if (ok_controllo==10){

for (var riga=0;riga<=7;riga++){

for (var col=0;col<=6;col++){

var num=col*8+riga;

var punti=0;

if (oggetto_cella[num]==tipo){

	for (var k=0;k<=2;k++){
		if (oggetto_cella[num+k*8+8]==tipo){
		punti=punti+1;
		}
	}

}


if (punti==3){vittoria=tipo;}


}
}


}

}




function controllo_verticale(tipo: int){

	if (ok_controllo==10){

for (var col=0;col<=6;col++){
for (var riga=0;riga<=7;riga++){


var num=riga+col*8;

var punti=0;

if (oggetto_cella[num]==tipo){

	for (var k=0;k<=2;k++){
		if (oggetto_cella[num+k+1]==tipo){
		punti=punti+1;
		}
	}

}


if (punti==3){vittoria=tipo;}


}
}


}

}


function controllo_diagonale_dx(tipo: int){


	if (ok_controllo==10){


for (var riga=0;riga<=7;riga++){
for (var col=0;col<=6;col++){

var num=col*8+riga;

var punti=0;

if (oggetto_cella[num]==tipo){

	for (var k=0;k<=2;k++){
		if (oggetto_cella[num+k*9+9]==tipo){
		punti=punti+1;
		}
	}

}


if (punti==3){vittoria=tipo;}


}
}


}

}


function controllo_diagonale_sx(tipo: int){


	if (ok_controllo==10){

for (var riga=0;riga<=7;riga++){
for (var col=3;col<=9;col++){

var num=col*8+riga;

var punti=0;

if (num>-1){


if (oggetto_cella[num]==tipo){

	for (var k=0;k<=2;k++){
		if (oggetto_cella[num-k*7-7]==tipo){
		punti=punti+1;
		}
	}

}

}



if (punti==3){vittoria=tipo;}


}
}


}

}